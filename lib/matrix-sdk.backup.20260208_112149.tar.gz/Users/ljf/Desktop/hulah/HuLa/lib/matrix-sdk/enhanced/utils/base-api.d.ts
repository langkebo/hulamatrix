import { type SynapseEnhancedHttpClient } from "./http.ts";
export declare abstract class BaseApi {
    protected readonly httpClient: SynapseEnhancedHttpClient;
    constructor(httpClient: SynapseEnhancedHttpClient);
    protected get<T>(endpoint: string, params?: unknown): Promise<T>;
    protected post<T>(endpoint: string, body?: unknown): Promise<T>;
    protected put<T>(endpoint: string, body?: unknown): Promise<T>;
    protected delete<T>(endpoint: string, params?: unknown): Promise<T>;
    protected patch<T>(endpoint: string, body?: unknown): Promise<T>;
    protected handleResponse<T>(response: {
        data?: T;
        status: number;
    }, errorMessage: string): T;
    protected withRetry<T>(operation: () => Promise<T>, maxRetries?: number, delay?: number): Promise<T>;
}
//# sourceMappingURL=base-api.d.ts.map