import { SynapseEnhancedError } from "./http.ts";
import { ErrorCode } from "./error-codes.ts";
export interface ErrorHandlerConfig {
    /** 是否记录错误日志 */
    enableLogging: boolean;
    /** 是否包含堆栈跟踪 */
    includeStackTrace: boolean;
    /** 是否返回详细错误信息 */
    includeDetails: boolean;
    /** 错误恢复建议 */
    recoverySuggestions: boolean;
    /** 最大错误上下文深度 */
    maxContextDepth: number;
}
export interface ErrorResponse {
    status: "error";
    error: string;
    errcode: ErrorCode;
    message: string;
    details?: Record<string, unknown>;
    context?: Record<string, unknown>;
    suggestion?: string;
    timestamp: string;
    request_id?: string;
}
export interface ErrorMetrics {
    error_count: number;
    error_by_type: Record<string, number>;
    last_error_at: string;
    error_rate: number;
}
export type ErrorHandlerCallback = (error: SynapseEnhancedError, context?: Record<string, unknown>) => void;
export declare class ErrorHandler {
    private static instance;
    private config;
    private callbacks;
    private metrics;
    private errorHistory;
    private constructor();
    static getInstance(config?: Partial<ErrorHandlerConfig>): ErrorHandler;
    static resetInstance(): void;
    handle(error: SynapseEnhancedError, context?: Record<string, unknown>): ErrorResponse;
    handleAsync(error: SynapseEnhancedError, context?: Record<string, unknown>): Promise<ErrorResponse>;
    registerCallback(callback: ErrorHandlerCallback): void;
    unregisterCallback(callback: ErrorHandlerCallback): void;
    getMetrics(): ErrorMetrics;
    getRecentErrors(limit?: number): Array<{
        error: SynapseEnhancedError;
        timestamp: Date;
    }>;
    clearHistory(): void;
    getConfig(): ErrorHandlerConfig;
    updateConfig(config: Partial<ErrorHandlerConfig>): void;
    wrapAsync<T>(fn: () => Promise<T>, context?: Record<string, unknown>): Promise<T>;
    createErrorBoundary<T>(componentName: string, fallback: (error: ErrorResponse) => T): (fn: () => Promise<T>) => Promise<T>;
    private isErrorResponse;
    private formatErrorResponse;
    private getUserFriendlyMessage;
    private getRecoverySuggestion;
    private isRetryable;
    private sanitizeContext;
    private sanitizeDetails;
    private logError;
    private updateMetrics;
    private notifyCallbacks;
}
export declare const defaultErrorHandler: ErrorHandler;
export declare function createErrorHandler(config?: Partial<ErrorHandlerConfig>): ErrorHandler;
//# sourceMappingURL=error-handler.d.ts.map