export interface DeprecationInfo {
    method: string;
    since: string;
    removedIn: string;
    alternative?: string;
    migrationGuide: string;
    severity: "low" | "medium" | "high";
}
export declare function registerDeprecation(info: DeprecationInfo): void;
export declare function getDeprecationInfo(method: string): DeprecationInfo | undefined;
export declare function isDeprecated(method: string): boolean;
export declare function logDeprecationWarning(method: string, context?: Record<string, unknown>): void;
export declare function getAllDeprecatedMethods(): DeprecationInfo[];
export declare function getDeprecatedMethodsBySeverity(severity: "low" | "medium" | "high"): DeprecationInfo[];
export declare function generateMigrationReport(): string;
export declare function deprecated(alternative?: string, migrationGuide?: string, severity?: "low" | "medium" | "high"): MethodDecorator;
//# sourceMappingURL=deprecation.d.ts.map