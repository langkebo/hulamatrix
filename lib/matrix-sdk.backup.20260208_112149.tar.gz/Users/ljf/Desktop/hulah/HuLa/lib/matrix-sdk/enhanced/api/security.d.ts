import { type SynapseEnhancedHttpClient } from "../utils/http.ts";
import type { IThreatDetection, IBlockedIp, IHighRiskIp, IReputationStats, ISecurityEvent, ISecurityEventParams, IIpStatus, ISecurityPolicy, ISecurityRule, ISecurityConfig } from "../models/types.ts";
/**
 * Security API - 安全相关的 API 接口
 * 提供威胁检测、IP 封禁、安全策略管理等功能
 */
export declare class SecurityApi {
    private httpClient;
    private readonly endpoint;
    /**
     * 创建 SecurityApi 实例
     * @param httpClient - HTTP 客户端实例
     */
    constructor(httpClient: SynapseEnhancedHttpClient);
    /**
     * 获取所有安全策略
     * @returns 安全策略列表
     */
    getPolicies(): Promise<ISecurityPolicy[]>;
    /**
     * 检测内容中的威胁
     * @param content - 待检测的内容
     * @param context - 可选的上下文信息
     * @returns 威胁检测结果
     */
    detectThreats(content: string, context?: Record<string, unknown>): Promise<IThreatDetection>;
    /**
     * 封禁 IP 地址
     * @param params - 封禁参数
     * @param params.ip_address - 要封禁的 IP 地址
     * @param params.reason - 封禁原因，可选
     * @param params.duration_hours - 封禁时长（小时），可选
     * @param params.permanent - 是否永久封禁，可选
     * @returns 操作是否成功
     */
    blockIp(params: {
        ip_address: string;
        reason?: string;
        duration_hours?: number;
        permanent?: boolean;
    }): Promise<boolean>;
    /**
     * 解封 IP 地址
     * @param ipAddress - 要解封的 IP 地址
     * @returns 操作是否成功
     */
    unblockIp(ipAddress: string): Promise<boolean>;
    /**
     * 获取 IP 地址状态
     * @param ipAddress - 要查询的 IP 地址
     * @returns IP 状态信息（是否封禁、信誉分数等）
     */
    getIpStatus(ipAddress: string): Promise<IIpStatus>;
    /**
     * 获取已封禁 IP 列表
     * @returns 封禁 IP 列表
     */
    getBlockedIps(): Promise<IBlockedIp[]>;
    /**
     * 获取高风险 IP 列表
     * @param threshold - 风险分数阈值，可选，默认为所有高风险 IP
     * @returns 高风险 IP 列表
     */
    getHighRiskIps(threshold?: number): Promise<IHighRiskIp[]>;
    /**
     * 获取信誉统计数据
     * @returns 信誉统计信息
     */
    getReputationStats(): Promise<IReputationStats>;
    /**
     * 获取安全事件列表
     * @param params - 可选查询参数（用户 ID、事件类型、严重程度、限制等）
     * @returns 安全事件列表
     */
    getSecurityEvents(params?: ISecurityEventParams): Promise<ISecurityEvent[]>;
    /**
     * 解决（关闭）安全事件
     * @param eventId - 事件 ID
     * @returns 操作是否成功
     */
    resolveEvent(eventId: string): Promise<boolean>;
    /**
     * 创建新的安全策略
     * @param params - 策略参数
     * @param params.name - 策略名称
     * @param params.description - 策略描述，可选
     * @param params.rules - 策略规则列表
     * @param params.enabled - 是否启用，可选
     * @returns 创建的策略
     */
    createPolicy(params: {
        name: string;
        description?: string;
        rules: ISecurityRule[];
        enabled?: boolean;
    }): Promise<ISecurityPolicy>;
    /**
     * 更新安全策略
     * @param policyId - 策略 ID
     * @param updates - 更新内容
     * @returns 更新后的策略
     */
    updatePolicy(policyId: string, updates: Partial<Omit<ISecurityPolicy, "id" | "created_at">>): Promise<ISecurityPolicy>;
    /**
     * 删除安全策略
     * @param policyId - 策略 ID
     * @returns 操作是否成功
     */
    deletePolicy(policyId: string): Promise<boolean>;
    /**
     * 设置策略启用状态
     * @param policyId - 策略 ID
     * @param enabled - 是否启用
     * @returns 更新后的策略
     */
    setPolicyEnabled(policyId: string, enabled: boolean): Promise<ISecurityPolicy>;
    /**
     * 添加规则到策略
     * @param policyId - 策略 ID
     * @param rule - 要添加的规则
     * @returns 更新后的策略
     */
    addPolicyRule(policyId: string, rule: ISecurityRule): Promise<ISecurityPolicy>;
    /**
     * 从策略中移除规则
     * @param policyId - 策略 ID
     * @param ruleIndex - 规则索引
     * @returns 更新后的策略
     */
    removePolicyRule(policyId: string, ruleIndex: number): Promise<ISecurityPolicy>;
    /**
     * 获取安全配置
     * @returns 安全配置信息
     */
    getConfig(): Promise<ISecurityConfig>;
    /**
     * 更新安全配置
     * @param config - 配置更新
     * @returns 更新后的安全配置
     */
    updateConfig(config: Partial<ISecurityConfig["settings"]>): Promise<ISecurityConfig>;
}
//# sourceMappingURL=security.d.ts.map