export interface CertificatePinningConfig {
    enabled: boolean;
    pins: Record<string, string[]>;
    validateChain: boolean;
    requireSameHost: boolean;
    onPinMismatch: "reject" | "warn" | "ignore";
}
export interface CertificateInfo {
    subject: string;
    issuer: string;
    validFrom: number;
    validTo: number;
    fingerprint: string;
    publicKeyFingerprint: string;
}
export declare class CertificatePinner {
    private config;
    private readonly DEFAULT_CONFIG;
    constructor(config?: Partial<CertificatePinningConfig>);
    updateConfig(config: Partial<CertificatePinningConfig>): void;
    isEnabled(): boolean;
    addPin(hostname: string, pin: string): void;
    removePin(hostname: string, pin?: string): void;
    clearPins(): void;
    validateConnection(hostname: string, certificate: CertificateInfo): Promise<CertificateValidationResult>;
    private matchesHostname;
    private validateCertificate;
    private isBase64Encoded;
    private isValidHostname;
    private isValidPin;
    private compareBase64Fingerprints;
    private base64ToArrayBuffer;
    private hexToArrayBuffer;
    extractCertificateInfo(connection: {
        hostname: string;
    }): Promise<CertificateInfo | null>;
    private parseCertificate;
    private generateFingerprint;
    private generatePublicKeyFingerprint;
}
export interface CertificateValidationResult {
    valid: boolean;
    error?: string;
    expectedPins?: string[];
    actualFingerprint?: string;
}
export declare class TLSSecurityManager {
    private certificatePinner;
    private allowedHosts;
    private blockedHosts;
    private securityPolicy;
    constructor(options?: {
        certificatePinning?: Partial<CertificatePinningConfig>;
        securityPolicy?: "strict" | "permissive" | "custom";
    });
    isConnectionSecure(hostname: string): boolean;
    validateConnection(hostname: string, certificate: CertificateInfo): Promise<boolean>;
    addAllowedHost(hostname: string): void;
    addBlockedHost(hostname: string): void;
    removeHostFromLists(hostname: string): void;
    clearHostLists(): void;
    getCertificatePinner(): CertificatePinner;
    setSecurityPolicy(policy: "strict" | "permissive" | "custom"): void;
}
//# sourceMappingURL=certificate-pinning.d.ts.map