export interface BasicMetrics {
    requestCount: number;
    errorCount: number;
    averageLatency: number;
}
export interface RequestMetrics {
    endpoint: string;
    method: string;
    duration: number;
    status: number;
    timestamp: Date;
}
export interface PerformanceHooks {
    onRequest?: (metrics: RequestMetrics) => void;
    onResponse?: (metrics: RequestMetrics) => void;
}
export declare class SimplePerformanceMonitor {
    private requestCount;
    private errorCount;
    private totalLatency;
    private hooks;
    setHooks(hooks: PerformanceHooks): void;
    recordRequest(endpoint: string, method: string, duration: number, status: number): void;
    getMetrics(): BasicMetrics;
    reset(): void;
}
export declare const defaultPerformanceMonitor: SimplePerformanceMonitor;
//# sourceMappingURL=simple-performance.d.ts.map