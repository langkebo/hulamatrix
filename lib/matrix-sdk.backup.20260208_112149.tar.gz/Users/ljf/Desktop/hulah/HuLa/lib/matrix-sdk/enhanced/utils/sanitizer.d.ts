/**
 * 内容安全模块
 *
 * 提供全面的输入清理和输出编码功能，防止 XSS 攻击和其他安全威胁。
 * 使用 DOMPurify 进行 HTML 清理，支持多种安全配置模式。
 */
interface SecurityThreat {
    type: ThreatType;
    pattern: RegExp;
    severity: "low" | "medium" | "high" | "critical";
    description: string;
}
type ThreatType = "SCRIPT_TAG" | "JAVASCRIPT_URI" | "EVENT_HANDLER" | "IFRAME_TAG" | "OBJECT_TAG" | "EMBED_TAG" | "EXPRESSION" | "DATA_URI" | "VBSCRIPT_URI" | "SVG_TAG" | "MATH_TAG" | "FORM_TAG" | "CSS_INJECTION" | "DOM_CLOBBERING" | "POLYGLOT" | "NAMED_ENTITY" | "NUMERIC_ENTITY" | "ZERO_WIDTH_CHAR" | "BIDIRECTIONAL" | "unicode_escape" | "obfuscation";
export interface SanitizeOptions {
    maxLength?: number;
    mode?: "html" | "text" | "strict";
    allowLinks?: boolean;
    allowFormatting?: boolean;
}
export interface SanitizeResult {
    sanitized: string;
    threatsDetected: number;
    wasTruncated: boolean;
}
export interface AdvancedSanitizeOptions extends SanitizeOptions {
    detectObfuscation?: boolean;
    maxLinks?: number;
    maxImages?: number;
    allowDataUrls?: boolean;
    allowRelativeUrls?: boolean;
    cssValidation?: boolean;
    reportThreats?: boolean;
    threatCallback?: (threat: SecurityThreat) => void;
}
export interface ThreatReport {
    threats: SecurityThreat[];
    severity: "none" | "low" | "medium" | "high" | "critical";
    cleaned: string;
    blocked: boolean;
}
export declare function detectAndReportThreats(content: string): ThreatReport;
export interface ContentSecurityPolicyDirective {
    directive: string;
    value: string;
}
export interface ContentSecurityPolicyOptions {
    directives?: ContentSecurityPolicyDirective[];
    reportUri?: string;
    reportOnly?: boolean;
}
export interface ContentSecurityPolicyResult {
    policy: string;
    directives: ContentSecurityPolicyDirective[];
    reportUri?: string;
    reportOnly: boolean;
}
export declare function generateContentSecurityPolicy(options?: ContentSecurityPolicyOptions): ContentSecurityPolicyResult;
export interface CustomSanitizationRule {
    name: string;
    pattern: RegExp;
    replacement: string;
    priority: number;
}
export declare class SanitizerBuilder {
    private customRules;
    private allowedTags;
    private forbiddenTags;
    private forbiddenAttributes;
    private maxLength;
    private strictMode;
    private enableObfuscationDetection;
    private maxLinks;
    private maxImages;
    addCustomRule(rule: CustomSanitizationRule): SanitizerBuilder;
    removeCustomRule(name: string): SanitizerBuilder;
    allowTag(tag: string): SanitizerBuilder;
    forbidTag(tag: string): SanitizerBuilder;
    allowAttribute(attr: string): SanitizerBuilder;
    forbidAttribute(attr: string): SanitizerBuilder;
    setMaxLength(length: number): SanitizerBuilder;
    enableStrictMode(): SanitizerBuilder;
    disableObfuscationDetection(): SanitizerBuilder;
    setMaxLinks(count: number): SanitizerBuilder;
    setMaxImages(count: number): SanitizerBuilder;
    build(): {
        sanitize: (content: unknown, options?: AdvancedSanitizeOptions) => SanitizeResult & ThreatReport;
        sanitizePlainText: (text: unknown, options?: {
            maxLength?: number;
        }) => string;
        sanitizeAttribute: (value: unknown) => string;
        sanitizeUrl: (url: unknown) => string;
        validateAndSanitizeInput: (input: unknown, options?: AdvancedSanitizeOptions) => {
            valid: boolean;
            sanitized: string;
            threats: SecurityThreat[];
            error?: string;
        };
    };
}
export declare function sanitizeContent(content: unknown, options?: AdvancedSanitizeOptions): SanitizeResult & ThreatReport;
export declare function sanitizePlainText(text: unknown, options?: {
    maxLength?: number;
}): string;
export declare function sanitizeAttribute(value: unknown): string;
export declare function sanitizeUrl(url: unknown): string;
export declare function sanitizeUserInput(input: unknown, maxLength?: number): string;
export declare function sanitizeCss(css: string): {
    safe: boolean;
    cleaned: string;
};
export declare function sanitizeHtmlAttributes(html: string): string;
export declare function validateAndSanitizeInput(input: unknown, options?: AdvancedSanitizeOptions): {
    valid: boolean;
    sanitized: string;
    threats: SecurityThreat[];
    error?: string;
};
export interface ValidationResult {
    valid: boolean;
    error?: string;
}
export declare function validateRoomId(roomId: unknown): ValidationResult;
export declare function validateMessageId(messageId: unknown): ValidationResult;
export declare function validateUserId(userId: unknown): ValidationResult;
export declare function validateEventId(eventId: unknown): ValidationResult;
export declare function sanitizeForStorage(data: Record<string, unknown>): Record<string, unknown>;
export {};
//# sourceMappingURL=sanitizer.d.ts.map