export interface RequestSigningConfig {
    enabled: boolean;
    secretKey: string;
    algorithm: "HMAC-SHA256" | "HMAC-SHA512";
    includeTimestamp: boolean;
    includeNonce: boolean;
    signatureHeaderName: string;
}
export interface SignedRequest {
    headers: Record<string, string>;
    signature: string;
    timestamp: number;
    nonce: string;
}
export declare class RequestSigner {
    private config;
    private readonly DEFAULT_CONFIG;
    constructor(config?: Partial<RequestSigningConfig>);
    updateConfig(config: Partial<RequestSigningConfig>): void;
    isEnabled(): boolean;
    private computeHmacSha256;
    private computeHmacSha512;
    private fallbackHmacSha256;
    private fallbackHmacSha512;
    private sha256;
    private sha512;
    private rotateRight;
    private generateNonce;
    generateSignature(method: string, path: string, timestamp: number, nonce: string, body?: string): Promise<string>;
    signRequest(method: string, path: string, body?: string): Promise<SignedRequest>;
    verifySignature(method: string, path: string, timestamp: number, nonce: string, body: string, providedSignature: string): Promise<boolean>;
}
//# sourceMappingURL=request-signer.d.ts.map