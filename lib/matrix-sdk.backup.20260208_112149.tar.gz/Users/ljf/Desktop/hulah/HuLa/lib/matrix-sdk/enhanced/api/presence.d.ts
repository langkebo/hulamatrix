import { type SynapseEnhancedHttpClient } from "../utils/http.ts";
import type { IPresenceApi, IPresenceStatus, ISetPresence, IStatusResponse } from "../models/types.ts";
export declare class PresenceApi implements IPresenceApi {
    private readonly httpClient;
    private readonly baseUrl;
    constructor(httpClient: SynapseEnhancedHttpClient, baseUrl?: string);
    getStatus(userId: string): Promise<IPresenceStatus>;
    setStatus(params: ISetPresence): Promise<IStatusResponse>;
    getPresence(userId: string): Promise<IPresenceStatus>;
    updatePresence(userId: string, presence: string, statusMsg?: string): Promise<void>;
}
//# sourceMappingURL=presence.d.ts.map