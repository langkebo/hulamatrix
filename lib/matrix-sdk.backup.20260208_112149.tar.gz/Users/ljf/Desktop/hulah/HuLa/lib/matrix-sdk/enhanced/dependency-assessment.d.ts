/**
 * Dependency Update Assessment for matrix-js-sdk Enhanced Module
 * Generated: 2024-01-19
 */
export declare const DEPENDENCY_ASSESSMENT: {
    summary: string;
    upToDate: {
        description: string;
        packages: {
            name: string;
            current: string;
            status: string;
        }[];
    };
    minorUpdatesAvailable: {
        description: string;
        packages: {
            name: string;
            current: string;
            latest: string;
            recommendation: string;
            priority: string;
        }[];
    };
    needsReview: {
        description: string;
        packages: {
            name: string;
            current: string;
            status: string;
            recommendation: string;
            priority: string;
        }[];
    };
    securityNotes: string[];
    recommendedActions: string[];
};
export declare function getDependencyUpdateSummary(): string;
export declare function getPackagesNeedingUpdate(): Array<{
    name: string;
    priority: string;
}>;
//# sourceMappingURL=dependency-assessment.d.ts.map