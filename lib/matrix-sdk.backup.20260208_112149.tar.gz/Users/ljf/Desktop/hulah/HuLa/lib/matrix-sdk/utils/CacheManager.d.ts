export interface CacheEntry<T> {
    value: T;
    expires: number;
    hits: number;
    lastAccess: number;
}
export interface CacheOptions {
    maxAge?: number;
    maxSize?: number;
    cleanupInterval?: number;
}
export declare class CacheManager {
    private cache;
    private maxAge;
    private maxSize;
    private cleanupInterval;
    private cleanupTimer;
    private hits;
    private misses;
    constructor(options?: CacheOptions);
    get<T>(key: string): T | null;
    set<T>(key: string, value: T, ttl?: number): void;
    has(key: string): boolean;
    delete(key: string): boolean;
    clear(): void;
    size(): number;
    getStats(): {
        hits: number;
        misses: number;
        hitRate: number;
        entries: number;
    };
    resetStats(): void;
    cleanup(): number;
    destroy(): void;
    private evictOldest;
    private startCleanup;
}
//# sourceMappingURL=CacheManager.d.ts.map