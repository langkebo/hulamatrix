import { type IdTokenClaims } from "oidc-client-ts";
import { type AccessTokens } from "../http-api/index.ts";
/**
 * @experimental
 * Class responsible for refreshing OIDC access tokens
 *
 * Client implementations will likely want to override {@link persistTokens} to persist tokens after successful refresh
 *
 */
export declare class OidcTokenRefresher {
    /**
     * The OIDC issuer as returned by the /auth_issuer API
     */
    private issuer;
    /**
     * id of this client as registered with the OP
     */
    private clientId;
    /**
     * redirectUri as registered with OP
     */
    private redirectUri;
    /**
     * Device ID of current session
     */
    protected deviceId: string;
    /**
     * idTokenClaims as returned from authorization grant
     * used to validate tokens
     */
    private readonly idTokenClaims;
    /**
     * This is now just a resolved promise and will be removed in a future version.
     * Initialisation is done lazily at token refresh time.
     * @deprecated Consumers no longer need to wait for this promise.
     */
    readonly oidcClientReady: Promise<void>;
    private initPromise?;
    private oidcClient;
    private inflightRefreshRequest?;
    constructor(
    /**
     * The OIDC issuer as returned by the /auth_issuer API
     */
    issuer: string, 
    /**
     * id of this client as registered with the OP
     */
    clientId: string, 
    /**
     * redirectUri as registered with OP
     */
    redirectUri: string, 
    /**
     * Device ID of current session
     */
    deviceId: string, 
    /**
     * idTokenClaims as returned from authorization grant
     * used to validate tokens
     */
    idTokenClaims: IdTokenClaims);
    /**
     * Ensures that the client is initialised.
     * @returns Promise that resolves when initialisation is complete
     * @throws if initialisation fails
     */
    private ensureInit;
    private initialiseOidcClient;
    /**
     * Attempt token refresh using given refresh token
     * @param refreshToken - refresh token to use in request with token issuer
     * @returns tokens - Promise that resolves with new access and refresh tokens
     * @throws when token refresh fails
     */
    doRefreshAccessToken(refreshToken: string): Promise<AccessTokens>;
    /**
     * Persist the new tokens, called after tokens are successfully refreshed.
     *
     * This function is intended to be overriden by the consumer when persistence is necessary.
     *
     * @param tokens.accessToken - new access token
     * @param tokens.refreshToken - OPTIONAL new refresh token
     */
    protected persistTokens(tokens: {
        accessToken: string;
        refreshToken?: string;
    }): Promise<void>;
    private getNewTokens;
}
//# sourceMappingURL=tokenRefresher.d.ts.map