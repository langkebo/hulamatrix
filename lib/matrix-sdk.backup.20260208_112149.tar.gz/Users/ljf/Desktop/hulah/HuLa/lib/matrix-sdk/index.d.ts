import * as matrixcs from "./matrix.ts";
export * from "./matrix.ts";
export * from "./enhanced/index.ts";
export default matrixcs;
//# sourceMappingURL=index.d.ts.map