import { type SynapseEnhancedHttpClient } from "../utils/http.ts";
export declare class FriendsVerificationApi {
    protected httpClient: SynapseEnhancedHttpClient;
    protected readonly baseUrl: string;
    constructor(httpClient: SynapseEnhancedHttpClient, baseUrl?: string);
    removeFriend(friendId: string): Promise<boolean>;
}
//# sourceMappingURL=friends-verification.d.ts.map