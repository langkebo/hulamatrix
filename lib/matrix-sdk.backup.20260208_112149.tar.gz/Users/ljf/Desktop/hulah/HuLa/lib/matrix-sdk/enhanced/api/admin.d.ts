import { type SynapseEnhancedHttpClient } from "../utils/http.ts";
import type { IAdminUser, IAdminRoom, IAdminParams, IAdminPaginationResult, ISystemStatistics, IHealthResponse, IPaginationParams, IRoomDetail, IRoomMessagesResponse, IAdminProfile, IAdminListResponse, IAuditLogResponse, ICreateAdminParams, IUpdateRoleParams, IDeleteResult, IConfigResponse, IBatchUserOperation, IBatchUserResponse, IBatchRoomOperation, IBatchRoomResponse, IBatchDeleteParams, IBatchDeleteResponse, IUserPermissionsResponse, IRoomSearchCriteria, IRoomSearchResponse, IMessageModerationParams, IMessageModerationResponse, IConfigExport, IAdminActivityResponse, IBlacklistResponse } from "../models/types.ts";
import { type IAdminApi } from "../models/security.types.ts";
/**
 * Admin API - 管理端 API 接口
 * 提供用户管理、房间管理、系统统计、黑名单管理等管理功能
 */
export declare class AdminApi implements IAdminApi {
    private httpClient;
    private readonly baseUrl;
    private readonly blacklistUrl;
    /**
     * 创建 AdminApi 实例
     * @param httpClient - HTTP 客户端实例
     * @param config - 可选配置
     * @param config.baseUrl - 基础 URL，默认为 SynapseAdminApi.BASE
     * @param config.blacklistUrl - 黑名单 API URL，默认为 SynapseAdminApi.BASE
     */
    constructor(httpClient: SynapseEnhancedHttpClient, config?: {
        baseUrl?: string;
        blacklistUrl?: string;
    });
    /**
     * 获取黑名单列表
     * @param params - 可选查询参数
     * @param params.type - 筛选类型，默认为 'all'
     * @param params.page - 页码，从 1 开始
     * @param params.limit - 每页数量限制
     * @returns 黑名单列表及分页信息
     */
    getBlacklist(params?: {
        type?: string;
        page?: number;
        limit?: number;
    }): Promise<IBlacklistResponse>;
    /**
     * 添加到黑名单
     * @param params - 黑名单参数
     * @param params.type - 目标类型 (user/room/ip)
     * @param params.target - 目标标识
     * @param params.reason - 添加原因
     * @param params.duration_hours - 封禁时长（小时），可选
     * @returns 操作是否成功
     */
    addToBlacklist(params: {
        type: string;
        target: string;
        reason: string;
        duration_hours?: string;
    }): Promise<boolean>;
    /**
     * 从黑名单移除
     * @param params - 移除参数
     * @param params.type - 目标类型 (user/room/ip)
     * @param params.target - 目标标识
     * @param params.reason - 移除原因，可选
     * @returns 操作是否成功
     */
    removeFromBlacklist(params: {
        type: string;
        target: string;
        reason?: string;
    }): Promise<boolean>;
    /**
     * 获取用户列表
     * @param params - 可选查询参数
     * @param params.page - 页码，从 1 开始
     * @param params.limit - 每页数量限制
     * @param params.search - 搜索关键词
     * @returns 用户列表及分页信息
     */
    getUsers(params?: IAdminParams): Promise<IAdminPaginationResult<IAdminUser>>;
    /**
     * 获取用户详情
     * @param userId - 用户 ID
     * @returns 用户详细信息，不存在则返回 null
     */
    getUserDetail(userId: string): Promise<IAdminUser | null>;
    /**
     * 获取房间列表
     * @param params - 可选查询参数
     * @param params.page - 页码，从 1 开始
     * @param params.limit - 每页数量限制
     * @param params.search - 搜索关键词
     * @param params.state - 房间状态筛选
     * @returns 房间列表及分页信息
     */
    getRooms(params?: IAdminParams): Promise<IAdminPaginationResult<IAdminRoom>>;
    /**
     * 获取系统统计数据
     * @param period - 统计周期 (day/week/month)，可选
     * @returns 系统统计数据
     */
    getStatistics(period?: "day" | "week" | "month"): Promise<ISystemStatistics>;
    /**
     * 获取系统健康状态
     * @returns 系统健康状态信息
     */
    getHealth(): Promise<IHealthResponse>;
    /**
     * 暂停用户
     * @param userId - 用户 ID
     * @param reason - 暂停原因，可选
     * @returns 操作结果
     */
    suspendUser(userId: string, reason?: string): Promise<IDeleteResult>;
    /**
     * 激活用户
     * @param userId - 用户 ID
     * @returns 操作结果
     */
    activateUser(userId: string): Promise<IDeleteResult>;
    /**
     * 获取房间详情
     * @param roomId - 房间 ID
     * @returns 房间详细信息，不存在则返回 null
     */
    getRoomDetail(roomId: string): Promise<IRoomDetail | null>;
    /**
     * 获取房间消息
     * @param roomId - 房间 ID
     * @param limit - 消息数量限制，可选
     * @returns 房间消息列表及分页信息
     */
    getRoomMessages(roomId: string, limit?: number): Promise<IRoomMessagesResponse>;
    /**
     * 删除房间
     * @param roomId - 房间 ID
     * @param reason - 删除原因，可选
     * @returns 操作是否成功
     */
    deleteRoom(roomId: string, reason?: string): Promise<boolean>;
    /**
     * 获取消息列表
     * @param roomId - 房间 ID
     * @param params - 可选分页参数
     * @param params.page - 页码
     * @param params.limit - 每页数量
     * @returns 消息列表及分页信息
     */
    getMessageList(roomId: string, params?: IPaginationParams): Promise<IRoomMessagesResponse>;
    /**
     * 删除消息
     * @param messageId - 消息 ID
     * @param reason - 删除原因，可选
     * @returns 操作是否成功
     */
    deleteMessage(messageId: string, reason?: string): Promise<boolean>;
    /**
     * 搜索消息
     * @param query - 搜索关键词
     * @param params - 可选分页参数
     * @param params.page - 页码
     * @param params.limit - 每页数量
     * @returns 匹配的消息列表及分页信息
     */
    searchMessages(query: string, params?: IPaginationParams): Promise<IRoomMessagesResponse>;
    /**
     * 获取仪表盘统计数据
     * @returns 系统统计数据
     */
    getDashboardStats(): Promise<ISystemStatistics>;
    /**
     * 获取管理员列表
     * @param params - 可选分页参数
     * @param params.page - 页码
     * @param params.limit - 每页数量
     * @returns 管理员列表及分页信息
     */
    getAdminList(params?: IPaginationParams): Promise<IAdminListResponse>;
    /**
     * 获取当前管理员 profile
     * @returns 管理员 profile 信息
     */
    getAdminProfile(): Promise<IAdminProfile>;
    /**
     * 创建新管理员
     * @param params - 创建参数 (user_id, is_root 等)
     * @returns 创建的管理员 ID
     */
    createAdmin(params: ICreateAdminParams): Promise<{
        admin_id: string;
    }>;
    /**
     * 更新管理员角色
     * @param params - 更新参数 (admin_id, new_role)
     * @returns 操作是否成功
     */
    updateAdminRole(params: IUpdateRoleParams): Promise<boolean>;
    /**
     * 删除管理员
     * @param adminId - 管理员 ID
     * @returns 操作是否成功
     */
    deleteAdmin(adminId: string): Promise<boolean>;
    /**
     * 获取审计日志
     * @param params - 可选分页参数
     * @param params.page - 页码
     * @param params.limit - 每页数量
     * @returns 审计日志列表及分页信息
     */
    getAuditLogs(params?: IPaginationParams): Promise<IAuditLogResponse>;
    /**
     * 获取系统配置
     * @returns 系统配置信息
     */
    getSystemConfig(): Promise<IConfigResponse>;
    /**
     * 更新系统配置
     * @param config - 配置对象
     * @returns 更新后的系统配置信息
     */
    updateSystemConfig(config: Record<string, unknown>): Promise<IConfigResponse>;
    /**
     * 获取用户权限
     * @param userId - 用户 ID
     * @returns 用户权限信息
     */
    getUserPermissions(userId: string): Promise<IUserPermissionsResponse>;
    /**
     * Executes multiple user operations in a single request.
     * Supports suspending, activating, and deleting users.
     *
     * @param operations - Array of user operations to execute
     * @returns Promise resolving to the batch operation response with individual results
     * @throws {SynapseEnhancedError} When input validation fails or API request fails
     * @throws {BatchOperationError} When one or more operations fail, containing details of each failure
     *
     * @example
     * ```typescript
     * const operations = [
     *     { user_id: "@spammer:example.com", action: "suspend", reason: "Spam behavior" },
     *     { user_id: "@inactive:example.com", action: "delete" },
     * ];
     *
     * try {
     *     const result = await adminApi.batchUserOperations(operations);
     *     console.log(`Processed ${result.total_success} users successfully`);
     * } catch (error) {
     *     if (isBatchOperationError(error)) {
     *         console.log(`Failed to process ${error.result.failureCount} users`);
     *         for (const failure of error.result.failures) {
     *             console.log(`  - ${failure.itemId}: ${failure.error}`);
     *         }
     *     }
     * }
     * ```
     */
    batchUserOperations(operations: IBatchUserOperation[]): Promise<IBatchUserResponse>;
    /**
     * 搜索房间
     * @param criteria - 搜索条件
     * @param params - 可选分页参数
     * @param params.page - 页码
     * @param params.limit - 每页数量
     * @returns 搜索结果及分页信息
     */
    searchRooms(criteria: IRoomSearchCriteria, params?: IPaginationParams): Promise<IRoomSearchResponse>;
    /**
     * Executes multiple room operations in a single request.
     * Supports deleting, archiving, and changing room visibility.
     *
     * @param operations - Array of room operations to execute
     * @returns Promise resolving to the batch operation response with individual results
     * @throws {SynapseEnhancedError} When input validation fails or API request fails
     * @throws {BatchOperationError} When one or more operations fail, containing details of each failure
     *
     * @example
     * ```typescript
     * const operations = [
     *     { room_id: "!abused:example.com", action: "delete", reason: "Violation of terms" },
     *     { room_id: "!old:example.com", action: "archive" },
     * ];
     *
     * try {
     *     const result = await adminApi.batchRoomOperations(operations);
     *     console.log(`Processed ${result.total_success} rooms successfully`);
     * } catch (error) {
     *     if (isBatchOperationError(error)) {
     *         console.log(`Failed to process ${error.result.failureCount} rooms`);
     *         console.log(error.toSummary());
     *     }
     * }
     * ```
     */
    batchRoomOperations(operations: IBatchRoomOperation[]): Promise<IBatchRoomResponse>;
    /**
     * Deletes multiple messages matching the specified criteria.
     * Allows bulk deletion based on user ID, room ID, time range, and limit.
     *
     * @param params - Criteria for selecting messages to delete
     * @returns Promise resolving to the delete result with counts of deleted and failed items
     * @throws {SynapseEnhancedError} When input validation fails or API request fails
     * @throws {BatchOperationError} When one or more deletions fail
     *
     * @example
     * ```typescript
     * const params = {
     *     criteria: {
     *         user_id: "@spamuser:example.com",
     *         limit: 100,
     *     },
     *     reason: "Spam messages",
     * };
     *
     * try {
     *     const result = await adminApi.batchDeleteMessages(params);
     *     console.log(`Deleted ${result.data.deleted_count} messages`);
     * } catch (error) {
     *     if (isBatchOperationError(error)) {
     *         console.log(`Failed to delete ${error.result.failureCount} messages`);
     *         console.log(`Failed message IDs: ${error.getFailedItems().join(", ")}`);
     *     }
     * }
     * ```
     */
    batchDeleteMessages(params: IBatchDeleteParams): Promise<IBatchDeleteResponse>;
    /**
     * 审核消息
     * @param params - 审核参数
     * @returns 审核结果
     */
    moderateMessages(params: IMessageModerationParams): Promise<IMessageModerationResponse>;
    /**
     * 获取管理员活动日志
     * @param params - 可选分页参数
     * @param params.page - 页码
     * @param params.limit - 每页数量
     * @returns 管理员活动记录及分页信息
     */
    getAdminActivity(params?: IPaginationParams): Promise<IAdminActivityResponse>;
    /**
     * 导出系统配置
     * @returns 系统配置导出信息
     */
    exportConfig(): Promise<IConfigExport>;
    /**
     * 获取配置版本历史
     * @returns 配置版本信息
     */
    getConfigVersions(): Promise<IConfigVersionsResponse>;
}
export interface IConfigVersionsResponse {
    versions: string[];
    current_version: string;
}
//# sourceMappingURL=admin.d.ts.map