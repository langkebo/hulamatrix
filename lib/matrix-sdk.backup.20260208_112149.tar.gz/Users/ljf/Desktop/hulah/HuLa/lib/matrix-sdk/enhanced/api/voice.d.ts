import { type SynapseEnhancedHttpClient } from "../utils/http.ts";
import type { IVoiceMessage, IVoiceInfo, IVoiceUploadParams, IVoiceConvertParams, IVoiceOptimizeParams, IConvertResult, IOptimizeResult } from "../models/types.ts";
export interface IVoiceConfig {
    supported_formats: string[];
    max_duration_seconds: number;
    max_file_size_bytes: number;
    default_format: string;
    default_quality: string;
    features: {
        conversion: boolean;
        optimization: boolean;
        premium: string[];
    };
}
export declare class VoiceApi {
    private httpClient;
    private readonly endpoint;
    constructor(httpClient: SynapseEnhancedHttpClient);
    /**
     * Get voice configuration
     */
    getConfig(): Promise<IVoiceConfig>;
    /**
     * Upload and process a voice message
     */
    upload(params: IVoiceUploadParams): Promise<IVoiceMessage>;
    /**
     * Get voice message info
     */
    getInfo(messageId: string): Promise<IVoiceInfo | null>;
    /**
     * Convert voice message to another format
     */
    convert(params: IVoiceConvertParams): Promise<IConvertResult>;
    /**
     * Optimize voice message file size
     */
    optimize(params: IVoiceOptimizeParams): Promise<IOptimizeResult>;
    delete(messageId: string): Promise<boolean>;
    getDownloadUrl(messageId: string): string;
}
//# sourceMappingURL=voice.d.ts.map