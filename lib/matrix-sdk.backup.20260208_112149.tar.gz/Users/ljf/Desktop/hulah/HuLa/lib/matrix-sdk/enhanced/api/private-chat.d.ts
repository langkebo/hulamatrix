import { type SynapseEnhancedHttpClient } from "../utils/http.ts";
import type { IPrivateChatApi, ICreateSession, IPrivateSession, ISendMessage, IPrivateMessage, IPaginationParams, IUnreadCount, ISearchMessagesParams, ISessionStatistics, IChatroomDetail, IChatroomFile, IVoiceMessageItem } from "../models/types.ts";
export declare class PrivateChatApi implements IPrivateChatApi {
    private httpClient;
    private readonly baseUrl;
    constructor(httpClient: SynapseEnhancedHttpClient, baseUrl?: string);
    createSession(params: ICreateSession): Promise<string>;
    getSessions(userId?: string): Promise<IPrivateSession[]>;
    getSessionDetail(sessionId: string): Promise<IPrivateSession | null>;
    closeSession(sessionId: string, userId: string): Promise<boolean>;
    sendMessage(params: ISendMessage): Promise<string>;
    getMessages(sessionId: string, params?: IPaginationParams): Promise<IPrivateMessage[]>;
    markAsRead(messageId: string, userId: string): Promise<boolean>;
    getUnreadCount(): Promise<IUnreadCount>;
    searchMessages(params: ISearchMessagesParams): Promise<IPrivateMessage[]>;
    getSessionStatistics(sessionId: string): Promise<ISessionStatistics>;
    getChatroomDetail(roomId: string): Promise<IChatroomDetail | null>;
    leaveChatroom(roomId: string): Promise<boolean>;
    muteChatroom(roomId: string, mute: boolean): Promise<boolean>;
    deleteMessage(roomId: string, messageId: string): Promise<boolean>;
    getFiles(roomId: string): Promise<IChatroomFile[]>;
    getVoiceMessages(roomId: string): Promise<IVoiceMessageItem[]>;
}
//# sourceMappingURL=private-chat.d.ts.map