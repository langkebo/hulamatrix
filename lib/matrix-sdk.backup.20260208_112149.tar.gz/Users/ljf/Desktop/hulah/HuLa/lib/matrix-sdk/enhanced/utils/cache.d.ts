export interface CacheEntry<T> {
    value: T;
    expiresAt: number;
    createdAt: number;
}
export interface CacheAdapter {
    get<T>(key: string): Promise<T | undefined>;
    set<T>(key: string, value: T, ttl?: number): Promise<void>;
    delete(key: string): Promise<void>;
    clear(): Promise<void>;
    has(key: string): boolean;
}
export interface CacheOptions {
    enabled?: boolean;
    defaultTTL?: number;
    maxEntries?: number;
}
export declare class MemoryCache implements CacheAdapter {
    private cache;
    private accessOrder;
    private options;
    constructor(options?: CacheOptions);
    get<T>(key: string): Promise<T | undefined>;
    set<T>(key: string, value: T, ttl?: number): Promise<void>;
    delete(key: string): Promise<void>;
    clear(): Promise<void>;
    has(key: string): boolean;
    private updateAccessOrder;
    private removeFromAccessOrder;
    private evictIfNeeded;
    get size(): number;
    cleanup(): void;
    invalidatePattern(pattern: RegExp): number;
    invalidatePrefix(prefix: string): number;
}
export declare const defaultCache: MemoryCache;
//# sourceMappingURL=cache.d.ts.map