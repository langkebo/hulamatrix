import type { IContent, IMentions } from "../matrix.ts";
import type { RelationEvent } from "../types.ts";
import type { CallMembership } from "./CallMembership.ts";
import { type CallMembershipIdentityParts } from "./EncryptionManager.ts";
export type EncryptionKeyMapKey = string;
export interface EncryptionKeyEntry {
    index: number;
    key: string;
}
/**
 * The mxID, deviceId and membership timestamp of a RTC session participant.
 */
export type ParticipantDeviceInfo = {
    userId: string;
    deviceId: string;
    membershipTs: number;
};
/**
 * A type representing the information needed to decrypt video streams.
 */
export type InboundEncryptionSession = {
    key: Uint8Array<ArrayBuffer>;
    membership: CallMembershipIdentityParts;
    keyIndex: number;
    creationTS: number;
};
/**
 * The information about the key used to encrypt video streams.
 */
export type OutboundEncryptionSession = {
    key: Uint8Array<ArrayBuffer>;
    creationTS: number;
    sharedWith: Array<ParticipantDeviceInfo>;
    keyId: number;
};
export interface EncryptionKeysEventContent {
    keys: EncryptionKeyEntry[];
    device_id: string;
    call_id: string;
    sent_ts?: number;
}
/**
 * THe content of a to-device event that contains encryption keys.
 */
export interface EncryptionKeysToDeviceEventContent {
    keys: {
        index: number;
        key: string;
    };
    member: {
        id: string;
        claimed_device_id: string;
    };
    room_id: string;
    session: {
        application: string;
        call_id: string;
        scope: string;
    };
    sent_ts?: number;
}
/**
 * @deprecated Use `RTCNotificationType` instead.
 */
export type CallNotifyType = "ring" | "notify";
/**
 * @deprecated Use `IRTCNotificationContent` instead.
 */
export interface ICallNotifyContent {
    "application": string;
    "m.mentions": IMentions;
    "notify_type": CallNotifyType;
    "call_id": string;
}
export type RTCNotificationType = "ring" | "notification";
/**
 * Represents the intention of the call from the perspective of the sending user.
 * May be any string, although `"audio"` and `"video"` are commonly accepted values.
 */
export type RTCCallIntent = "audio" | "video" | string;
/**
 * This will check if the content has all the expected fields to be a valid IRTCNotificationContent.
 * It will also cap the lifetime to 90000ms (1.5 min) if a higher value is provided.
 * @param content
 * @throws if the content is invalid
 * @returns a parsed IRTCNotificationContent
 */
export declare function parseCallNotificationContent(content: IContent): IRTCNotificationContent;
/**
 * Interface for `org.matrix.msc4075.rtc.notification` events.
 * Don't cast event content to this directly. Use `parseCallNotificationContent` instead to validate the content first.
 */
export interface IRTCNotificationContent extends RelationEvent {
    "m.mentions"?: IMentions;
    "notification_type": RTCNotificationType;
    /**
     * The initial intent of the calling user.
     */
    "m.call.intent"?: RTCCallIntent;
    "sender_ts": number;
    "lifetime": number;
}
/**
 * MSC4310 decline event content for `org.matrix.msc4310.rtc.decline`.
 * Sent as a standard m.reference relation to an `org.matrix.msc4075.rtc.notification` event.
 */
export interface IRTCDeclineContent extends RelationEvent {
}
export declare enum Status {
    Disconnected = "Disconnected",
    Connecting = "Connecting",
    Connected = "Connected",
    Disconnecting = "Disconnecting",
    Unknown = "Unknown"
}
/**
 * A type collecting call encryption statistics for a session.
 */
export type Statistics = {
    counters: {
        /**
         * The number of times we have sent a room event containing encryption keys.
         */
        roomEventEncryptionKeysSent: number;
        /**
         * The number of times we have received a room event containing encryption keys.
         */
        roomEventEncryptionKeysReceived: number;
    };
    totals: {
        /**
         * The total age (in milliseconds) of all room events containing encryption keys that we have received.
         * We track the total age so that we can later calculate the average age of all keys received.
         */
        roomEventEncryptionKeysReceivedTotalAge: number;
    };
};
export declare const isMyMembership: (m: CallMembership, userId: string, deviceId: string) => boolean;
/**
 *  A RTC transport is a JSON object that describes how to connect to a RTC member.
 */
export interface Transport {
    type: string;
    [key: string]: unknown;
}
//# sourceMappingURL=types.d.ts.map