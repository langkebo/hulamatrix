export interface ChunkingOptions {
    chunkSize: number;
    overlap?: number;
    progressCallback?: (progress: ProgressInfo) => void;
}
export interface ProgressInfo {
    processed: number;
    total: number;
    percentage: number;
    currentChunk?: unknown;
}
export interface StreamProcessorOptions {
    highWaterMark?: number;
    transform?: (chunk: unknown) => unknown;
    onProgress?: (progress: ProgressInfo) => void;
}
export interface LargeJsonProcessOptions {
    maxDepth?: number;
    maxStringLength?: number;
    maxTokens?: number;
    path?: string[];
    onProgress?: (progress: ProgressInfo) => void;
}
export interface SecurityLimits {
    maxDepth: number;
    maxStringLength: number;
    maxTokens: number;
    maxObjectKeys: number;
    maxArrayLength: number;
}
export declare class BigDataProcessor {
    private readonly CHUNK_SIZE;
    private securityLimits;
    constructor(securityLimits?: Partial<SecurityLimits>);
    updateSecurityLimits(limits: Partial<SecurityLimits>): void;
    getSecurityLimits(): SecurityLimits;
    chunkData<T>(data: T[], options: ChunkingOptions): T[][];
    mergeChunks<T>(chunks: T[][], options?: {
        deduplicate?: boolean;
    }): T[];
    processInBatches<T, R>(items: T[], processor: (batch: T[]) => Promise<R[]>, options?: {
        batchSize?: number;
        onProgress?: (progress: ProgressInfo) => void;
    }): Promise<R[]>;
    processLargeJSON<T>(jsonString: string, options?: LargeJsonProcessOptions): Promise<T>;
    streamProcess<T, R>(dataStream: AsyncIterable<T>, processor: (chunk: T) => Promise<R>, options?: StreamProcessorOptions): Promise<R[]>;
    processLargeFile(file: File, options?: {
        chunkSize?: number;
        onProgress?: (progress: ProgressInfo) => void;
    }): Promise<string>;
    writeLargeFile(data: string, options?: {
        chunkSize?: number;
        onProgress?: (progress: ProgressInfo) => void;
    }): Promise<Blob>;
    paginateFetch<T>(fetchFn: (page: number, pageSize: number) => Promise<{
        items: T[];
        hasMore: boolean;
    }>, options?: {
        pageSize?: number;
        maxPages?: number;
        onProgress?: (progress: ProgressInfo) => void;
    }): Promise<T[]>;
}
export declare function safeJsonParse<T>(jsonString: string, options?: LargeJsonProcessOptions): Promise<T>;
export declare class MemoryEfficientArray<T> {
    private readonly maxSize;
    private data;
    private itemToIndex;
    private accessHistory;
    private readonly onEvict?;
    constructor(maxSize?: number, options?: {
        onEvict?: (item: T) => void;
    });
    push(item: T): void;
    private evict;
    get(index: number): T | undefined;
    has(item: T): boolean;
    getIndex(item: T): number | undefined;
    remove(item: T): boolean;
    toArray(): T[];
    clear(): void;
    get length(): number;
    isFull(): boolean;
    getUtilization(): number;
}
export declare class StreamingTransformer<T, R> {
    private buffer;
    private readonly highWaterMark;
    private readonly transformFn;
    private readonly flushFn?;
    constructor(transformFn: (chunk: T) => R, options?: {
        highWaterMark?: number;
        flushFn?: (buffer: T[]) => R[];
    });
    transform(chunk: T): Promise<R | null>;
    flush(): Promise<R | null>;
    transformAll(chunks: T[]): Promise<R[]>;
}
export declare class DebouncedProcessor<T> {
    private buffer;
    private readonly maxBufferSize;
    private readonly maxWaitTime;
    private timeoutId;
    private readonly processor;
    private readonly onProgress?;
    constructor(processor: (items: T[]) => Promise<void>, options?: {
        maxBufferSize?: number;
        maxWaitTime?: number;
        onProgress?: (progress: ProgressInfo) => void;
    });
    add(item: T): Promise<void>;
    flush(): Promise<void>;
}
export declare function generateBatches<T>(items: T[], batchSize: number): AsyncGenerator<T[]>;
export declare function generateChunks(data: string, chunkSize: number): AsyncGenerator<string>;
export interface AdaptiveChunkOptions {
    availableMemory?: number;
    itemSizeEstimate?: number;
    safetyFactor?: number;
    minChunkSize?: number;
    maxChunkSize?: number;
}
export interface AdaptiveChunkResult {
    optimalChunkSize: number;
    estimatedItemsPerChunk: number;
    estimatedMemoryUsage: number;
}
export declare function calculateAdaptiveChunkSize<T>(_items: T[], options?: AdaptiveChunkOptions): AdaptiveChunkResult;
export interface WorkerTask<T, R> {
    id: string;
    data: T[];
    processor: string;
    resultType?: R;
}
export interface WorkerResult<R> {
    id: string;
    results: R[];
    error?: string;
}
export interface WorkerPoolOptions {
    maxWorkers?: number;
    taskTimeout?: number;
    onWorkerError?: (workerId: string, error: Error) => void;
    onTaskComplete?: (taskId: string, results: unknown[]) => void;
}
export declare class WorkerPool<T, R> {
    private readonly maxWorkers;
    private readonly taskTimeout;
    private readonly workerScript;
    private readonly onWorkerError?;
    private readonly onTaskComplete?;
    private taskQueue;
    private pendingTasks;
    private activeWorkers;
    private workerIdCounter;
    constructor(workerScript: string, options?: WorkerPoolOptions);
    processBatch(items: T[], processor: string): Promise<R[]>;
    private scheduleTask;
    private executeTask;
    private runWorkerTask;
    shutdown(): Promise<void>;
    getQueueLength(): number;
    getActiveWorkerCount(): number;
    getPendingTaskCount(): number;
}
export interface BatchProcessingOptions {
    batchSize?: number;
    maxWorkers?: number;
    useParallelProcessing?: boolean;
    onProgress?: (progress: ProgressInfo) => void;
    onBatchComplete?: (batchIndex: number, results: unknown[]) => void;
}
export declare function processItemsInBatches<T, R>(items: T[], processor: (batch: T[]) => Promise<R[]>, options?: BatchProcessingOptions): Promise<R[]>;
//# sourceMappingURL=big-data-processor.d.ts.map