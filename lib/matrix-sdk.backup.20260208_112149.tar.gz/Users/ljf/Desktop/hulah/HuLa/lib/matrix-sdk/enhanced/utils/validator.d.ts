export interface ValidationResult {
    valid: boolean;
    error?: string;
    code?: string;
}
export declare function validateUserId(userId: string): ValidationResult;
export declare function validateRoomId(roomId: string): ValidationResult;
export declare function validateEventId(eventId: string): ValidationResult;
export declare function validateEmail(email: string): ValidationResult;
export declare function validateUsername(username: string): ValidationResult;
export declare function validatePassword(password: string): ValidationResult;
export declare function validatePaginationParams(params?: {
    limit?: number;
    cursor?: string;
    page?: number;
}): void;
export declare function validateCategoryName(name: string): ValidationResult;
export declare function validateRemark(remark: string): ValidationResult;
export declare function validateSearchQuery(query: string): ValidationResult;
export declare function validateIpAddress(ipAddress: string): ValidationResult;
export declare function validateBlockReason(reason?: string): ValidationResult;
export declare function validateDeleteReason(reason?: string): ValidationResult;
export declare function throwIfInvalid(result: ValidationResult, customMessage?: string): void;
export declare function isValidUserId(userId: string): boolean;
export declare function isValidRoomId(roomId: string): boolean;
export declare function isValidEmail(email: string): boolean;
export declare function isValidUsername(username: string): boolean;
export declare function validateString(value: unknown, paramName: string, options?: {
    minLength?: number;
    maxLength?: number;
    pattern?: RegExp;
}): string;
export declare function validateNumber(value: unknown, paramName: string, options?: {
    min?: number;
    max?: number;
    integer?: boolean;
}): number;
export declare function validateBoolean(value: unknown, paramName: string): boolean;
export declare function validateArray<T>(value: unknown, paramName: string, options?: {
    minLength?: number;
    maxLength?: number;
    itemValidator?: (item: unknown) => T;
}): T[];
export declare function validateObject<T extends Record<string, unknown>>(value: unknown, paramName: string, schema?: Record<string, {
    required?: boolean;
    validator?: (val: unknown) => unknown;
}>): T;
export declare function validateServerName(serverName: string): string;
export declare function validateMessageId(messageId: string): ValidationResult;
export declare function sanitizeContent(content: string, options?: {
    maxLength?: number;
}): string;
//# sourceMappingURL=validator.d.ts.map