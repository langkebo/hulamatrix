/**
 * Separate exports file for the indexeddb web worker, which is designed
 * to be used separately
 */
/** The {@link IndexedDBStoreWorker} class. */
export { IndexedDBStoreWorker } from "./store/indexeddb-store-worker.ts";
//# sourceMappingURL=indexeddb-worker.d.ts.map