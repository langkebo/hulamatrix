import type { SynapseEnhancedHttpClient } from "../utils/http.ts";
import type { IFriendRequestV2 } from "../models/friend-requests.types.ts";
export declare class FriendRequestsApi {
    private httpClient;
    constructor(httpClient: SynapseEnhancedHttpClient);
    sendFriendRequest(params: {
        target_user_id: string;
        message?: string;
    }): Promise<IFriendRequestV2>;
    acceptFriendRequest(roomId: string): Promise<{
        room_id: string;
        status: string;
        direct_chats: Record<string, string[]>;
    }>;
    rejectFriendRequest(roomId: string): Promise<{
        room_id: string;
        status: string;
    }>;
}
//# sourceMappingURL=friend-requests.d.ts.map